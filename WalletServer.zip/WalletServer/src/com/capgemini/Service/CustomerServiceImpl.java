package com.capgemini.Service;

import java.math.BigDecimal;
import java.util.Map;

import com.capgemini.Beans.Customer;
import com.capgemini.Beans.Wallet;
import com.capgemini.Dao.ICustomerDao;






public class CustomerServiceImpl implements ICustomerService {
	
	
	public CustomerServiceImpl(ICustomerDao customerdao) {
		super();
		this.customerdao = customerdao;
	}
	private ICustomerDao customerdao;
	

	public CustomerServiceImpl(Map<String, Customer> data){
		customerdao= (ICustomerDao) new CustomerServiceImpl(data);
	}
	@Override
	public Customer createAccount(String mobileNumber, String customerName, BigDecimal balance) throws Exception {
		Customer customer=null;

		customer=new Customer(customerName,mobileNumber,new Wallet());
				if(customerdao.findByMobileNumber(mobileNumber) != null)
					throw new Exception("The account with mobile Number "+ mobileNumber+" is already created");
				customerdao.save(customer);
			

			return customer;
	}
	

	@Override
	public Customer fundTransfer(int mobileNumber, int mobileNumber1) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public Customer depositAmount(int mobileNumber, BigDecimal balance) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public Customer showBalance(int mobileNumber) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public Customer showTransactions(int mobileNumber) {
		// TODO Auto-generated method stub
		return null;
	}


	
	
	

		
	}


