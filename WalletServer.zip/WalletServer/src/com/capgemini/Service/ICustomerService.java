package com.capgemini.Service;

import java.math.BigDecimal;

import com.capgemini.Beans.Customer;

public interface ICustomerService {
	
	public Customer createAccount(String mobileNumber, String customerName, BigDecimal balance) throws Exception;
	public Customer fundTransfer(int mobileNumber, int mobileNumber1);
	public Customer depositAmount(int mobileNumber,  BigDecimal balance);
	public Customer showBalance(int mobileNumber);
	public Customer showTransactions(int mobileNumber);
	


}
