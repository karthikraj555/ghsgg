package com.capgemini.UI;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import com.capgemini.Beans.Customer;
import com.capgemini.Service.CustomerServiceImpl;
import com.capgemini.Service.ICustomerService;


public class Client {
	
	
	
	private static ICustomerService customerservice;
	private Map<String,Customer> data=new HashMap<String, Customer>();
	public Client() 
	{
		System.out.println("Welcome to Wallet Application");
		customerservice=new CustomerServiceImpl(data);
	}
public static void main(String args[])
{
		
	System.out.println("1) Create New Account");
		System.out.println("2) Check Your Balance");
		
		Scanner sc=new Scanner(System.in);
		String mobileNumber; 
		BigDecimal balance; 
		String customerName ;
		
		switch (sc.nextInt()) 
		{
		case 1: System.out.print("Enter ur name: ");
	        	customerName = sc.next();
	        	System.out.print("Enter ur mobileNumber: ");
	        	mobileNumber = sc.next();
	        	System.out.print("Enter Balance : ");
	        	balance=sc.nextBigDecimal();
			
			try {
				Customer customer1=customerservice.createAccount(mobileNumber, customerName, balance);
				System.out.println("Thank you, "+customer1.getCustomerName()+" Your Payment wallet account has been created successfully with Balance "+balance);
			}
			catch (Exception e)
			{
				System.out.println(e.getMessage());
			}

			break;
		}
	}
						

}

