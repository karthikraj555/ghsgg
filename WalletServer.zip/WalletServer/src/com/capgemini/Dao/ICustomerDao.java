package com.capgemini.Dao;

import java.math.BigDecimal;

import com.capgemini.Beans.Customer;

public interface ICustomerDao {
	
	Customer save(Customer customer);


	Customer updateCustomerWalletBalance(String mobileNumber,BigDecimal amount);

	Customer findByMobileNumber(String mobileNumber);


}
