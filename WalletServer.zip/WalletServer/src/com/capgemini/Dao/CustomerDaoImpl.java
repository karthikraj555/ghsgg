package com.capgemini.Dao;

import java.math.BigDecimal;
import java.util.Map;

import com.capgemini.Beans.Customer;



public class CustomerDaoImpl implements ICustomerDao {
	
	private Map<String, Customer> data;
	
	public CustomerDaoImpl(Map<String, Customer> data) {
		super();
		this.data = data;
	}
	



	@Override
	public Customer updateCustomerWalletBalance(String mobileNumber, BigDecimal amount) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customer save(Customer customer) {
		if(data.containsKey(customer.getMobileNumber()))
		{
			data.replace(customer.getMobileNumber(), customer);
		}
		else
			data.put(customer.getMobileNumber(), customer);
		return customer;
		
	}


	@Override
	public Customer findByMobileNumber(String mobileNumber) {
		Customer customer=null;
		customer=data.get(mobileNumber);
		return customer;
	}
}
	

